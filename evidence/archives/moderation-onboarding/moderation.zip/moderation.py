"""Run the supplied account-moderation example explicitly, outside the docs build."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import random
from importlib.metadata import version
from pathlib import Path

import lightning.pytorch as lit
import pyarrow as pa
import pyarrow.parquet as pq
import relflow as rf
import torch

SEED = 42
TEXT_MODEL = "google/bert_uncased_L-2_H-128_A-2"
MESSAGES = (
    ("Thanks for sharing the guide.", "ordinary"),
    ("Where can I find the next community event?", "ordinary"),
    ("This helped me fix the problem.", "ordinary"),
    ("I disagree, but appreciate your explanation.", "ordinary"),
    ("The documentation link is on the project page.", "ordinary"),
    ("You are an idiot.", "abusive"),
    ("Nobody wants your stupid comments here.", "abusive"),
    ("Stop posting, you are useless.", "abusive"),
    ("Click my profile for a special offer.", "promotion"),
    ("Visit my page for a limited-time deal.", "promotion"),
    ("Message me privately to claim your prize.", "promotion"),
    ("Follow my profile for exclusive discounts.", "promotion"),
)


def schema(*, labeled: bool) -> pa.Schema:
    """Keep list and record types explicit, including empty histories and queues."""
    message = [pa.field("message_id", pa.string()), pa.field("text", pa.string())]
    if labeled:
        message.extend([pa.field("needs_review", pa.bool_()), pa.field("review_seconds", pa.float64())])
    fields = [
        pa.field("account_id", pa.string()),
        pa.field("account_age_days", pa.float64()),
        pa.field(
            "previous_warnings",
            pa.list_(
                pa.field(
                    "element",
                    pa.struct([pa.field("outcome", pa.string()), pa.field("days_ago", pa.float64())]),
                )
            ),
        ),
        pa.field("messages", pa.list_(pa.field("element", pa.struct(message)))),
    ]
    if labeled:
        fields.append(pa.field("needs_account_review", pa.bool_()))
    return pa.schema(fields)


def observations(count: int, *, offset: int, seed: int) -> list[dict]:
    """Generate a workflow fixture from a declared fictional moderation policy."""
    rng = random.Random(seed)
    records = []
    for ordinal in range(offset, offset + count):
        age = float(rng.choice((7, 14, 30, 60, 180, 365, 730)))
        warning_count = rng.randrange(4)
        warnings = [
            {"outcome": rng.choice(("removed", "dismissed")), "days_ago": float(days)}
            for days in sorted(rng.sample(range(1, 61), warning_count), reverse=True)
        ]
        has_removal = any(warning["outcome"] == "removed" for warning in warnings)
        messages = []
        for index in range(rng.randrange(1, 5)):
            text, kind = rng.choice(MESSAGES)
            review = kind == "abusive" or (kind == "promotion" and (age < 30 or has_removal))
            messages.append(
                {
                    "message_id": f"message-{ordinal:04d}-{index}",
                    "text": text,
                    "needs_review": review,
                    "review_seconds": 90.0 if review else 15.0,
                }
            )
        review_count = sum(message["needs_review"] for message in messages)
        records.append(
            {
                "account_id": f"account-{ordinal:04d}",
                "account_age_days": age,
                "previous_warnings": warnings,
                "messages": messages,
                "needs_account_review": review_count >= 2 or (review_count >= 1 and has_removal),
            }
        )
    return records


def prepare(directory: Path) -> None:
    """Write the reproducible supplied data; these are not real user records."""
    directory.mkdir(parents=True, exist_ok=True)
    train = observations(2048, offset=0, seed=SEED)
    train[0] = {
        "account_id": "account-0000",
        "account_age_days": 14.0,
        "previous_warnings": [{"outcome": "removed", "days_ago": 2.0}],
        "messages": [
            {
                "message_id": "message-0000-0",
                "text": "You are an idiot.",
                "needs_review": True,
                "review_seconds": 90.0,
            },
            {
                "message_id": "message-0000-1",
                "text": "Thanks for sharing the guide.",
                "needs_review": False,
                "review_seconds": 15.0,
            },
        ],
        "needs_account_review": True,
    }
    validate = observations(512, offset=2048, seed=SEED + 1)
    requests = [
        train[0],
        {
            "account_id": "account-established",
            "account_age_days": 730.0,
            "previous_warnings": [],
            "messages": [{"message_id": "message-established", "text": "Thanks for sharing the guide."}],
        },
        {
            "account_id": "account-new",
            "account_age_days": 7.0,
            "previous_warnings": [],
            "messages": [{"message_id": "message-new", "text": "Click my profile for a special offer."}],
        },
        {"account_id": "account-empty", "account_age_days": 365.0, "previous_warnings": [], "messages": []},
    ]
    for name, records, labeled in (
        ("train", train, True),
        ("validation", validate, True),
        ("requests", requests, False),
    ):
        pq.write_table(pa.Table.from_pylist(records, schema=schema(labeled=labeled)), directory / f"{name}.parquet")


class Warning(rf.Branch):
    outcome = rf.Category
    days_ago = rf.Number


class Message(rf.Branch):
    text = rf.Text(cache=64)
    needs_review = rf.Boolean(mask=True)


class ModerationModel(rf.Model):
    account_age_days = rf.Number
    previous_warnings = Warning(length=8, overflow="tail")
    messages = Message(length=4, overflow="tail")
    needs_account_review = rf.Boolean(mask=True)


def readable(table: pa.Table, *, extended: bool) -> list[dict]:
    """Present each score beside its retained application identifier."""
    results = []
    for row in table.to_pylist():
        prediction = row["predictions"]
        messages = []
        for source, result in zip(row["inputs"]["messages"], prediction["messages"], strict=True):
            message = {
                "message_id": source["message_id"],
                "review_probability": round(result["needs_review"]["content"]["probability"], 4),
            }
            if extended:
                message["estimated_review_seconds"] = round(result["review_seconds"]["content"], 1)
            messages.append(message)
        results.append(
            {
                "account_id": row["inputs"]["account_id"],
                "account_review_probability": round(prediction["needs_account_review"]["content"]["probability"], 4),
                "messages": messages,
            }
        )
    return results


def run(args: argparse.Namespace) -> None:
    """Train, reload, predict, then add a numeric task to the trained schema."""
    torch.set_num_threads(args.threads)
    lit.seed_everything(SEED, workers=True)
    directory = Path(__file__).resolve().parent
    if args.prepare:
        prepare(directory)
        return
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    data = rf.ArrowDataModule(
        train=str(directory / "train.parquet"),
        validate=str(directory / "validation.parquet"),
        num_workers=0,
        pin_memory=False,
    )
    options = {
        "batch_size": 128,
        "learning_rate": 1e-3,
        "accelerator": "cpu",
        "devices": 1,
        "precision": "32-true",
        "max_epochs": args.epochs,
        "logger": False,
        "enable_progress_bar": False,
        "enable_model_summary": False,
        "num_sanity_val_steps": 0,
        "deterministic": True,
    }
    if args.smoke:
        options.update(max_epochs=1, limit_train_batches=1, limit_val_batches=1)
    model = ModerationModel(preset="small")
    model.fit(data, checkpoint_dir=output / "checkpoints", **options)
    model.save(output / "moderation.rf")
    loaded = rf.Model.load(output / "moderation.rf")
    requests = pq.read_table(directory / "requests.parquet")
    predictions = loaded.predict(requests, retain=("account_id", "messages"), batch_size=128)
    original = readable(predictions, extended=False)
    pq.write_table(predictions, output / "predictions.parquet")

    loaded.extend(
        rf.where("address") == rf.Address("messages"),
        review_seconds=rf.Number(mask=True),
    )
    data = rf.ArrowDataModule(
        train=str(directory / "train.parquet"),
        validate=str(directory / "validation.parquet"),
        num_workers=0,
        pin_memory=False,
    )
    options["max_epochs"] = 1 if args.smoke else args.extension_epochs
    loaded.fit(data, checkpoint_dir=output / "extension-checkpoints", **options)
    loaded.save(output / "moderation-with-duration.rf")
    extended = loaded.predict(requests, retain=("account_id", "messages"), batch_size=128)
    result = {
        "seed": SEED,
        "smoke": args.smoke,
        "relflow_version": loaded.version,
        "python_version": platform.python_version(),
        "torch_version": torch.__version__,
        "lightning_version": version("lightning"),
        "pyarrow_version": pa.__version__,
        "transformers_version": version("transformers"),
        "text_model": TEXT_MODEL,
        "architecture_preset": "small",
        "declaration": "ModerationModel",
        "threads": args.threads,
        "training_rows": pq.read_metadata(directory / "train.parquet").num_rows,
        "validation_rows": pq.read_metadata(directory / "validation.parquet").num_rows,
        "training": options,
        "initial_epochs": 1 if args.smoke else args.epochs,
        "extension_epochs": options["max_epochs"],
        "sha256": {
            name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
            for name in ("moderation.py", "train.parquet", "validation.parquet", "requests.parquet")
        },
        "initial_predictions": original,
        "extended_predictions": readable(extended, extended=True),
    }
    (output / "run.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["extended_predictions"], indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("moderation-run"))
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--extension-epochs", type=int, default=4)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--prepare", action="store_true", help="Recreate the supplied synthetic Parquet files.")
    parser.add_argument("--smoke", action="store_true", help="Run one training and validation batch for each schema.")
    run(parser.parse_args())
