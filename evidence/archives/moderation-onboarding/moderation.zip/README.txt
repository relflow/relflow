relflow moderation example

Run from this extracted directory:

    uv run --no-project --python 3.12 --with "relflow[text] @ git+https://github.com/relflow/relflow.git@dc64b85d75a85b3cef8ceada1869ee512f2fbe65" moderation.py

This example uses the relflow 0.5.0 class-schema API and the named small
architecture preset. The command pins its source revision so the example
can run before that release is published. Model fields are declared on
Warning, Message, and ModerationModel classes; model construction selects
ModerationModel(preset="small"). Training options are passed explicitly.

The default run uses CPU, seed 42, 2,048 training accounts, 512 validation
accounts, eight initial epochs and four epochs after adding the numeric task.
The first use of Text may download its frozen Hugging Face encoder assets.

Files:
    moderation.py       Model, runner, and reproducible fixture generator.
    train.parquet       Labeled account snapshots used for training.
    validation.parquet  Labeled snapshots with separate account identifiers.
    requests.parquet    Four requests without outcome labels, including an empty queue.
    recorded-run.json   Actual output, settings, versions, and hashes from one run.

The script writes artifacts and a new run.json under moderation-run/.
Use --output PATH to choose another output directory.
Use --smoke for one training and validation batch per schema.
Use --prepare to regenerate the supplied synthetic data with seed 42.

The data follows a fictional moderation policy documented in the script.
It demonstrates training, saving/loading, structured multi-task prediction,
and schema extension. It is not a real-world moderation benchmark, evidence
of comparative accuracy, or a production moderation policy.

Full tutorial: https://www.relflow.ai/en/latest/learn/moderation.html
