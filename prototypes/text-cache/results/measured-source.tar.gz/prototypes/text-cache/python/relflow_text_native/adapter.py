"""Experimental Text extension using the existing geometry and Torch cache.

The native owner speaks the production protocol and reads the same SQLite
format. NATIVE_TEXT_MODE=owner selects the Python client as an ablation;
NATIVE_TEXT_MODE=full additionally consumes Arrow arrays in a PyO3 client.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
from typing import Literal
from weakref import WeakValueDictionary, finalize

import numpy as np
import pyarrow as pa

from relflow.structs.enums import Component
from relflow.tensorfields.base import Extension
from relflow.tensorfields.extensions import text
from relflow.tensorfields.extensions.text_cache.context import Encoding, signature, tokenizer_identity
from relflow.tensorfields.extensions.text_cache.store import MAX_FRAME, MAX_ROWS, Client, Endpoint, Owner, stop


class Connection(Client):
    instances = WeakValueDictionary()

    def __init__(self, endpoint):
        super().__init__(endpoint)
        from .native import Client as NativeClient

        self.native = NativeClient(endpoint.port, endpoint.auth)

    def request(self, op, meta=None, payload=b""):
        if self.process != os.getpid():
            self.__init__(self.endpoint)
        return memoryview(self.native.request(op, json.dumps(meta or {}, separators=(",", ":")).encode(), payload))

    def close(self):
        self.native.close()


class NativeOwner(Owner):
    instances = WeakValueDictionary()

    def start(self):
        with self.lock:
            if self.process is not None:
                if self.process.poll() is not None:
                    raise RuntimeError("native text owner exited; recreate the model and loader")
                return self.client
            self.path.mkdir(parents=True, exist_ok=True)
            auth = os.urandom(32)
            self.log = tempfile.TemporaryFile()
            self.process = subprocess.Popen(
                [
                    os.environ["RELFLOW_NATIVE_OWNER"],
                    str(self.path / "cache.sqlite3"),
                    str(self.memory * 2**20),
                    str(self.capacity or 0),
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=self.log,
            )
            self.process.stdin.write(auth)
            self.process.stdin.flush()
            ready = self.process.stdout.readline()
            if not ready:
                self.process.wait(timeout=10)
                self.log.seek(0)
                detail = self.log.read().decode(errors="replace")
                self.close()
                raise RuntimeError(f"could not start native text owner: {detail}")
            description = json.loads(ready)
            self.endpoint = Endpoint(description["port"], auth, description["identity"], self.pid)
            client_type = Client if os.environ.get("NATIVE_TEXT_MODE") == "owner" else Connection
            self.client = client_type.open(self.endpoint)
            self.finalizer = finalize(self, stop, self.process, self.client, self.log, self.pid)
            return self.client


class NativeEncoding(Encoding):
    def __init__(self, model, length, batch_size, path, memory, capacity, endpoint=None):
        super().__init__(model, length, batch_size, path, memory, capacity, endpoint)
        self.owner = NativeOwner.open(path, memory, capacity) if endpoint is None else NativeOwner.hold(endpoint)

    @property
    def client(self):
        if self.connection is None:
            if self.endpoint is None:
                self.endpoint = self.owner.start().endpoint
            client_type = Client if os.environ.get("NATIVE_TEXT_MODE") == "owner" else Connection
            self.connection = client_type.open(self.endpoint)
        return self.connection

    def identify(self, texts, tokenizer):
        if os.environ.get("NATIVE_TEXT_MODE") == "owner":
            return super().identify(texts, tokenizer)
        if not isinstance(texts, pa.Array):
            texts = pa.array(texts, type=pa.large_string())
        with self.lock:
            settings = signature(tokenizer)
            if self.tokenizer is not tokenizer:
                self.base = tokenizer_identity(tokenizer)
                self.tokenizer = tokenizer
                self.namespace = ""
            if self.settings != settings or not self.namespace:
                self.namespace = hashlib.sha256(
                    repr((self.model, self.base, self.length, settings)).encode()
                ).hexdigest()
                self.settings = settings
            output = np.empty(len(texts), dtype=np.int64)
            chunk = min(MAX_ROWS, self.batch_size, (MAX_FRAME - 65536) // (self.length * 16 + 40))
            if chunk <= 0:
                raise ValueError("token length exceeds native frame budget")
            for start in range(0, len(texts), chunk):
                selected = texts.slice(start, min(chunk, len(texts) - start))
                reply, keys = self.client.native.identify_arrow(selected, self.namespace, self.length)
                ids = np.frombuffer(reply[: len(selected) * 8], dtype="<i8").copy()
                ready = np.frombuffer(reply[len(selected) * 8 :], dtype=np.uint8)
                missing = np.flatnonzero(ready == 0)
                if len(missing):
                    # Python text objects exist only at the tokenizer's cold boundary.
                    strings = selected.take(pa.array(missing)).to_pylist()
                    encoded = tokenizer(
                        strings, padding="max_length", truncation=True, max_length=self.length, return_tensors="np"
                    )
                    rows = np.stack(
                        (
                            np.asarray(encoded["input_ids"], dtype=np.int64),
                            np.asarray(encoded["attention_mask"], dtype=np.int64),
                        ),
                        axis=1,
                    )
                    if rows.shape != (len(missing), 2, self.length):
                        raise ValueError("tokenizer returned an invalid native token batch")
                    selected_keys = [keys[int(i) * 32 : (int(i) + 1) * 32] for i in missing]
                    ids[missing] = self.client.tokens(ids[missing], selected_keys, rows, self.namespace)
                output[start : start + len(selected)] = ids
            return output


extension = Extension(
    name="text_native",
    types=(str,),
    requires={"transformers": "relflow[text]", "relflow_text_native": "native prototype"},
    callbacks=text.text.callback_factories,
)


@extension.register(Component.Request)
class Request(text.Request):
    type: Literal["text_native"] = "text_native"


@extension.register(Component.Embedder)
class Embedder(text.Embedder):
    def __init__(self, schema, address):
        super().__init__(schema, address)
        request = self.request
        capacity = None if isinstance(request.cache, bool) else request.cache
        self.store = (
            NativeEncoding(
                request.model, request.max_length, request.tokenizer_batch_size, request.store, request.memory, capacity
            )
            if request.cache
            else None
        )


for role, component in text.text.components.items():
    if role not in (Component.Request, Component.Embedder):
        extension.register(role, component)
