//! Experimental native cache data plane. The wire and SQLite formats match
//! relflow's Python owner so language costs can be compared on the same IDs.
pub mod store;
pub mod wire;
#[cfg(feature = "python")]
mod python;
