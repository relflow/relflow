use anyhow::{Result, ensure};
use std::io::{Read, Write};
use std::net::TcpStream;

pub const MAX_FRAME: usize = 32 * 1024 * 1024;
pub const MAX_ROWS: usize = 4096;

pub fn call(stream: &mut TcpStream, op: u8, meta: &[u8], payload: &[u8]) -> Result<Vec<u8>> {
    let size = 5 + meta.len() + payload.len();
    ensure!(size <= MAX_FRAME && meta.len() <= 65536, "text cache request exceeds frame budget");
    let mut frame = Vec::with_capacity(size + 4);
    frame.extend_from_slice(&(size as u32).to_le_bytes());
    frame.push(op);
    frame.extend_from_slice(&(meta.len() as u32).to_le_bytes());
    frame.extend_from_slice(meta);
    frame.extend_from_slice(payload);
    stream.write_all(&frame)?;
    let mut header = [0; 4];
    stream.read_exact(&mut header)?;
    let size = u32::from_le_bytes(header) as usize;
    ensure!((1..=MAX_FRAME + 1).contains(&size), "invalid text cache response size");
    let mut response = vec![0; size];
    stream.read_exact(&mut response)?;
    ensure!(response[0] == 0, "{}", String::from_utf8_lossy(&response[1..]));
    response.remove(0);
    Ok(response)
}

pub fn ids(data: &[u8], n: usize) -> Result<Vec<i64>> {
    ensure!(data.len() == n * 8, "text ID batch has incorrect size");
    Ok(data.chunks_exact(8).map(|row| i64::from_le_bytes(row.try_into().unwrap())).collect())
}
