use anyhow::{Result, bail, ensure};
use moka::sync::Cache;
use rusqlite::{Connection, OptionalExtension, params};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::path::Path;
use std::sync::{Arc, Condvar, Mutex};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;
use crate::wire::{MAX_FRAME, MAX_ROWS, ids};

#[derive(Clone, Eq, PartialEq, Hash)]
pub enum Key { Alias([u8; 32]), Vector(i64, [u8; 32]) }
#[derive(Clone)]
pub enum Hot { Alias(i64), Vector(Arc<[u8]>) }
#[derive(Default)]
pub struct Counts {
    identified: AtomicU64, alias_hits: AtomicU64, vector_requests: AtomicU64,
    vector_hits: AtomicU64, disk_vectors: AtomicU64, encoder_claims: AtomicU64,
}

type Claim = (i64, String);
pub struct Store {
    connection: Mutex<Connection>, hot: Cache<Key, Hot>, memory: u64,
    pub identity: String, claims: Mutex<HashMap<Claim, u64>>, changed: Condvar, counts: Counts,
}

impl Store {
    pub fn open(path: &Path, memory: u64, capacity: u64) -> Result<Self> {
        if let Some(parent) = path.parent() { std::fs::create_dir_all(parent)?; }
        let connection = Connection::open(path)?;
        connection.busy_timeout(Duration::from_secs(60))?;
        connection.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA cache_size=-4096; PRAGMA mmap_size=0;
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY AUTOINCREMENT, key BLOB UNIQUE NOT NULL, length INTEGER NOT NULL, canonical INTEGER);
            CREATE TABLE IF NOT EXISTS token_rows (id INTEGER PRIMARY KEY AUTOINCREMENT, key BLOB UNIQUE NOT NULL, length INTEGER NOT NULL, tokens BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS vectors (id INTEGER NOT NULL, variant TEXT NOT NULL, width INTEGER NOT NULL, value BLOB NOT NULL, PRIMARY KEY (id,variant)) WITHOUT ROWID;
            INSERT OR IGNORE INTO metadata VALUES ('identity',lower(hex(randomblob(32))));
            INSERT OR IGNORE INTO metadata VALUES ('items','0');
            INSERT OR IGNORE INTO metadata VALUES ('tokens','0');
            INSERT OR IGNORE INTO metadata VALUES ('vectors','0');")?;
        let identity = connection.query_row("SELECT value FROM metadata WHERE key='identity'", [], |r| r.get(0))?;
        let minimum = if capacity == 0 {160} else {160.max(memory.div_ceil(capacity))};
        ensure!(minimum <= u32::MAX as u64, "entry charge exceeds supported cache weight");
        let hot = Cache::builder().max_capacity(memory).weigher(move |_: &Key, value: &Hot| {
            let payload = match value { Hot::Alias(_) => 16, Hot::Vector(bytes) => bytes.len() as u64 };
            minimum.max(160 + payload) as u32
        }).build();
        Ok(Self { connection: Mutex::new(connection), hot, memory, identity, claims: Mutex::new(HashMap::new()), changed: Condvar::new(), counts: Counts::default() })
    }

    pub fn identify(&self, keys: &[[u8;32]], length: i64) -> Result<Vec<u8>> {
        ensure!(length > 0, "text token length must be positive");
        self.counts.identified.fetch_add(keys.len() as u64, Ordering::Relaxed);
        let mut output = vec![0; keys.len()*9];
        let mut missing = Vec::new();
        for (index,key) in keys.iter().enumerate() {
            if let Some(Hot::Alias(id)) = self.hot.get(&Key::Alias(*key)) {
                output[index*8..index*8+8].copy_from_slice(&id.to_le_bytes());
                output[keys.len()*8+index] = 1;
                self.counts.alias_hits.fetch_add(1, Ordering::Relaxed);
            } else { missing.push(index); }
        }
        if missing.is_empty() { return Ok(output); }
        let mut connection = self.connection.lock().unwrap();
        let transaction = connection.transaction()?;
        let mut inserted = 0;
        {
            let mut select = transaction.prepare_cached("SELECT id,length,canonical FROM items WHERE key=?")?;
            let mut insert = transaction.prepare_cached("INSERT INTO items(key,length) VALUES (?,?) ON CONFLICT(key) DO NOTHING")?;
            for index in missing {
                let key = keys[index].as_slice();
                let mut row = select.query_row([key], |r| Ok((r.get::<_,i64>(0)?,r.get::<_,i64>(1)?,r.get::<_,Option<i64>>(2)?))).optional()?;
                if row.is_none() {
                    inserted += insert.execute(params![key,length])?;
                    row = Some(select.query_row([key], |r| Ok((r.get(0)?,r.get(1)?,r.get(2)?)))?);
                }
                let (alias, stored_length, canonical) = row.unwrap();
                ensure!(stored_length == length, "text alias has a different token length");
                output[index*8..index*8+8].copy_from_slice(&canonical.unwrap_or(alias).to_le_bytes());
                if let Some(id) = canonical {
                    output[keys.len()*8+index] = 1;
                    self.hot.insert(Key::Alias(keys[index]), Hot::Alias(id));
                }
            }
        }
        transaction.execute("UPDATE metadata SET value=CAST(value AS INTEGER)+? WHERE key='items'",[inserted as i64])?;
        transaction.commit()?;
        self.hot.run_pending_tasks();
        Ok(output)
    }

    pub fn tokens(&self, aliases: &[i64], keys: &[[u8;32]], rows: &[u8], length: usize, namespace: &str) -> Result<Vec<u8>> {
        ensure!(rows.len() == aliases.len()*length*16, "text token batch has incorrect size");
        let mut connection = self.connection.lock().unwrap();
        let transaction = connection.transaction()?;
        let mut canonical = Vec::with_capacity(aliases.len());
        let mut inserted = 0;
        {
            let mut alias = transaction.prepare_cached("SELECT key,length,canonical FROM items WHERE id=?")?;
            let mut previous = transaction.prepare_cached("SELECT tokens FROM token_rows WHERE id=?")?;
            let mut insert = transaction.prepare_cached("INSERT OR IGNORE INTO token_rows(key,length,tokens) VALUES (?,?,?)")?;
            let mut find = transaction.prepare_cached("SELECT id FROM token_rows WHERE key=?")?;
            let mut update = transaction.prepare_cached("UPDATE items SET canonical=? WHERE id=?")?;
            for (index,id) in aliases.iter().enumerate() {
                let payload = &rows[index*length*16..(index+1)*length*16];
                let stored = alias.query_row([id], |r| Ok((r.get::<_,Vec<u8>>(0)?,r.get::<_,i64>(1)?,r.get::<_,Option<i64>>(2)?))).optional()?;
                let (key,width,ready) = stored.ok_or_else(|| anyhow::anyhow!("text alias has no token row"))?;
                ensure!(key == keys[index] && width == length as i64, "text fill does not match its alias, key or length");
                if let Some(ready) = ready {
                    let existing: Vec<u8> = previous.query_row([ready],|r| r.get(0))?;
                    ensure!(existing == payload, "conflicting token rows; use a distinct tokenizer identity");
                    canonical.push(ready);
                } else {
                    let mut hash = Sha256::new(); hash.update(namespace.as_bytes()); hash.update(payload);
                    let key: [u8;32] = hash.finalize().into();
                    inserted += insert.execute(params![key.as_slice(),length as i64,payload])?;
                    let ready: i64 = find.query_row([key.as_slice()],|r| r.get(0))?;
                    update.execute(params![ready,id])?;
                    canonical.push(ready);
                }
            }
        }
        transaction.execute("UPDATE metadata SET value=CAST(value AS INTEGER)+? WHERE key='tokens'",[inserted as i64])?;
        transaction.commit()?;
        for (key,id) in keys.iter().zip(&canonical) { self.hot.insert(Key::Alias(*key),Hot::Alias(*id)); }
        self.hot.run_pending_tasks();
        Ok(canonical.iter().flat_map(|id| id.to_le_bytes()).collect())
    }

    pub fn get(&self, identifiers: &[i64], variant: &str, width: usize, length: usize, owner: u64) -> Result<Vec<u8>> {
        self.counts.vector_requests.fetch_add(identifiers.len() as u64,Ordering::Relaxed);
        let version: [u8;32] = Sha256::digest(variant.as_bytes()).into();
        let mut status = vec![0; identifiers.len()];
        let mut vectors = Vec::new(); let mut tokens = Vec::new();
        let connection = self.connection.lock().unwrap();
        let mut vector = connection.prepare_cached("SELECT width,value FROM vectors WHERE id=? AND variant=?")?;
        let mut token = connection.prepare_cached("SELECT length,tokens FROM token_rows WHERE id=?")?;
        let mut claims = self.claims.lock().unwrap();
        let mut owned = claims.values().filter(|id| **id == owner).count();
        for (index,id) in identifiers.iter().enumerate() {
            let key = Key::Vector(*id,version);
            if let Some(Hot::Vector(value)) = self.hot.get(&key) {
                ensure!(value.len() == width*4,"text vector width mismatch");
                status[index] = 1; vectors.push(value);
                self.counts.vector_hits.fetch_add(1,Ordering::Relaxed); continue;
            }
            if let Some((stored_width,value)) = vector.query_row(params![id,variant],|r| Ok((r.get::<_,i64>(0)?,r.get::<_,Vec<u8>>(1)?))).optional()? {
                ensure!(stored_width == width as i64 && value.len() == width*4,"text vector width mismatch");
                let value: Arc<[u8]> = value.into(); self.hot.insert(key,Hot::Vector(value.clone()));
                vectors.push(value); status[index] = 1;
                self.counts.disk_vectors.fetch_add(1,Ordering::Relaxed); continue;
            }
            let claim = (*id,variant.to_owned());
            if let Some(claimed) = claims.get(&claim) {
                if *claimed != owner { status[index] = 2; continue; }
            } else {
                ensure!(owned < MAX_ROWS,"connection exceeds 4096 in-flight encodings");
                owned += 1;
            }
            let stored = token.query_row([id],|r| Ok((r.get::<_,i64>(0)?,r.get::<_,Vec<u8>>(1)?))).optional()?;
            let (stored_length,value) = stored.ok_or_else(|| anyhow::anyhow!("text ID {id} has no token row"))?;
            ensure!(stored_length == length as i64 && value.len() == length*16,"text token length mismatch");
            claims.insert(claim,owner); tokens.push(value);
            self.counts.encoder_claims.fetch_add(1,Ordering::Relaxed);
        }
        drop(claims); drop(vector); drop(token); drop(connection);
        let mut output = status;
        for value in vectors { output.extend_from_slice(&value); }
        for value in tokens { output.extend_from_slice(&value); }
        self.hot.run_pending_tasks();
        Ok(output)
    }

    pub fn put(&self, identifiers: &[i64], variant: &str, rows: &[u8], width: usize, owner: u64) -> Result<Vec<u8>> {
        ensure!(rows.len() == identifiers.len()*width*4,"text vector fill size mismatch");
        let mut connection = self.connection.lock().unwrap();
        let transaction = connection.transaction()?;
        let mut claims = self.claims.lock().unwrap();
        let mut output = Vec::with_capacity(rows.len()); let mut inserted = 0;
        {
            let mut insert = transaction.prepare_cached("INSERT OR IGNORE INTO vectors VALUES (?,?,?,?)")?;
            let mut select = transaction.prepare_cached("SELECT width,value FROM vectors WHERE id=? AND variant=?")?;
            for (index,id) in identifiers.iter().enumerate() {
                ensure!(claims.get(&(*id,variant.to_owned())) == Some(&owner),"text vector fill has no matching claim");
                inserted += insert.execute(params![id,variant,width as i64,&rows[index*width*4..(index+1)*width*4]])?;
                let (stored_width,value) = select.query_row(params![id,variant],|r| Ok((r.get::<_,i64>(0)?,r.get::<_,Vec<u8>>(1)?)))?;
                ensure!(stored_width == width as i64,"text vector width mismatch"); output.extend_from_slice(&value);
            }
        }
        transaction.execute("UPDATE metadata SET value=CAST(value AS INTEGER)+? WHERE key='vectors'",[inserted as i64])?;
        transaction.commit()?;
        for id in identifiers { claims.remove(&(*id,variant.to_owned())); }
        self.changed.notify_all();
        Ok(output)
    }

    pub fn release(&self, owner: u64) {
        self.claims.lock().unwrap().retain(|_,value| *value != owner); self.changed.notify_all();
    }
    pub fn wait(&self) { drop(self.changed.wait_timeout(self.claims.lock().unwrap(),Duration::from_millis(100)).unwrap()); }
    pub fn stats(&self) -> Result<Value> {
        let connection = self.connection.lock().unwrap(); self.hot.run_pending_tasks();
        let count = |name| connection.query_row("SELECT CAST(value AS INTEGER) FROM metadata WHERE key=?",[name],|r| r.get::<_,i64>(0));
        let load = |counter: &AtomicU64| counter.load(Ordering::Relaxed);
        Ok(json!({"identity":self.identity,"identified":load(&self.counts.identified),"alias_hits":load(&self.counts.alias_hits),"vector_requests":load(&self.counts.vector_requests),"vector_hits":load(&self.counts.vector_hits),"disk_vectors":load(&self.counts.disk_vectors),"encoder_claims":load(&self.counts.encoder_claims),"aliases":count("items")?,"entries":count("tokens")?,"vectors":count("vectors")?,"memory":self.memory,"hot_bytes":self.hot.weighted_size(),"hot_entries":self.hot.entry_count(),"page_bytes":4194304,"claims":self.claims.lock().unwrap().len()}))
    }

    pub fn dispatch(&self, frame: &[u8], owner: u64) -> Result<Vec<u8>> {
        ensure!(frame.len() >= 5,"truncated request");
        let op = frame[0]; let size = u32::from_le_bytes(frame[1..5].try_into()?) as usize;
        ensure!(size <= 65536 && frame.len() >= 5+size,"invalid metadata size");
        let meta: Value = serde_json::from_slice(&frame[5..5+size])?;
        let data = &frame[5+size..];
        if op == 5 { return Ok(serde_json::to_vec(&self.stats()?)?); }
        if op == 6 { return Ok(Vec::new()); }
        let integer = |name| -> Result<usize> { Ok(meta[name].as_u64().ok_or_else(|| anyhow::anyhow!("invalid {name}"))?.try_into()?) };
        let text = |name| -> Result<&str> { meta[name].as_str().ok_or_else(|| anyhow::anyhow!("invalid {name}")) };
        let n = integer("n")?; ensure!(n <= MAX_ROWS,"request exceeds 4096 rows");
        if op == 1 {
            ensure!(data.len() == n*32,"invalid key batch");
            let keys: Vec<[u8;32]> = data.chunks_exact(32).map(|v|v.try_into().unwrap()).collect();
            return self.identify(&keys, integer("length")?.try_into()?);
        }
        if op == 7 { self.release(owner); return Ok(Vec::new()); }
        if op == 8 { self.wait(); return Ok(Vec::new()); }
        ensure!(data.len() >= n*8,"truncated ID batch");
        let identifiers = ids(&data[..n*8],n)?; let data = &data[n*8..];
        if op == 2 {
            let length = integer("length")?; ensure!(length > 0 && length <= MAX_FRAME/16,"invalid token length");
            ensure!(data.len() == n*(32+length*16),"invalid token batch");
            let keys: Vec<[u8;32]> = data[..n*32].chunks_exact(32).map(|v|v.try_into().unwrap()).collect();
            return self.tokens(&identifiers,&keys,&data[n*32..],length,text("namespace")?);
        }
        if op == 3 || op == 4 {
            let width = integer("width")?; ensure!(width > 0 && width <= MAX_FRAME/4,"invalid vector width");
            if op == 4 { return self.put(&identifiers,text("variant")?,data,width,owner); }
            let length = integer("length")?;
            ensure!(length > 0 && length <= MAX_FRAME/16 && n*(width*4).max(length*16)+n <= MAX_FRAME,"lookup exceeds frame budget");
            ensure!(data.is_empty(),"lookup has trailing bytes");
            return self.get(&identifiers,text("variant")?,width,length,owner);
        }
        bail!("unknown text cache operation {op}")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;
    fn token_rows(count: usize) -> Vec<u8> {
        (0..count).flat_map(|i| [i as i64,2,1,1].into_iter().flat_map(i64::to_le_bytes)).collect()
    }
    fn fill(store: &Store, count: usize) -> (Vec<[u8;32]>,Vec<i64>) {
        let keys: Vec<[u8;32]> = (0..count).map(|i|Sha256::digest(i.to_le_bytes()).into()).collect();
        let reply = store.identify(&keys,2).unwrap();
        assert_eq!(&reply[count*8..],vec![0;count]);
        let aliases = ids(&reply[..count*8],count).unwrap();
        let reply = store.tokens(&aliases,&keys,&token_rows(count),2,"tokens").unwrap();
        (keys,ids(&reply,count).unwrap())
    }
    #[test]
    fn durable_ids_vectors_and_bounded_ram() {
        let directory = tempdir().unwrap(); let path = directory.path().join("cache.sqlite3");
        let store = Store::open(&path,2048,0).unwrap(); let identity = store.identity.clone();
        let (keys,ids) = fill(&store,1000);
        let result = store.get(&ids,"fp32",128,2,1).unwrap(); assert_eq!(&result[..1000],vec![0;1000]);
        let vectors: Vec<u8> = (0..128000).flat_map(|i|(i as f32).to_le_bytes()).collect();
        assert_eq!(store.put(&ids,"fp32",&vectors,128,1).unwrap(),vectors);
        for chunk in ids.chunks(100) { assert_eq!(&store.get(chunk,"fp32",128,2,2).unwrap()[..chunk.len()],vec![1;chunk.len()]); }
        assert!(store.stats().unwrap()["hot_bytes"].as_u64().unwrap()<=2048);
        drop(store);
        let store = Store::open(&path,0,0).unwrap(); assert_eq!(identity,store.identity);
        let reply = store.identify(&keys,2).unwrap(); assert_eq!(crate::wire::ids(&reply[..8000],1000).unwrap(),ids);
        assert_eq!(&reply[8000..],vec![1;1000]);
        assert_eq!(store.stats().unwrap()["entries"],1000);
        let reply = store.get(&ids,"fp32",128,2,2).unwrap(); assert_eq!(&reply[1000..],vectors);
        assert_eq!(store.stats().unwrap()["hot_bytes"],0);
    }
    #[test]
    fn canonicalization_claim_release_precision_and_rollback() {
        let directory = tempdir().unwrap(); let store = Store::open(&directory.path().join("cache.sqlite3"),4096,0).unwrap();
        let keys = [[1;32],[2;32]];
        let reply = store.identify(&keys,2).unwrap(); let aliases = ids(&reply[..16],2).unwrap();
        let rows: Vec<u8> = [1_i64,2,1,1,1,2,1,1].into_iter().flat_map(i64::to_le_bytes).collect();
        let reply = store.tokens(&aliases,&keys,&rows,2,"tokenizer").unwrap(); let ids = ids(&reply,2).unwrap();
        assert_eq!(ids[0],ids[1]); assert_eq!(store.stats().unwrap()["entries"],1);
        let id = &ids[..1]; assert_eq!(store.get(id,"fp32",4,2,1).unwrap()[0],0);
        assert_eq!(store.get(id,"fp32",4,2,2).unwrap()[0],2); store.release(1);
        assert_eq!(store.get(id,"fp32",4,2,2).unwrap()[0],0);
        store.put(id,"fp32",&[0;16],4,2).unwrap(); assert_eq!(store.get(id,"bf16",4,2,3).unwrap()[0],0);
        store.release(3); assert_eq!(store.stats().unwrap()["claims"],0);
        let mut wrong = rows.clone(); wrong[0] = 9;
        assert!(store.tokens(&aliases,&keys,&wrong,2,"tokenizer").is_err());
        assert_eq!(store.stats().unwrap()["entries"],1);
        assert_eq!(store.get(id,"fp32",4,2,3).unwrap()[0],1);
    }
}
